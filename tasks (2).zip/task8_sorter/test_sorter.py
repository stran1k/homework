import unittest
from sorter import Sorter

class TestSorter(unittest.TestCase):

    # bubble_sort
    def test_bubble_sort_basic(self):
        self.assertEqual(Sorter.bubble_sort([5, 2, 9, 1]), [1, 2, 5, 9])

    def test_bubble_sort_empty(self):
        self.assertEqual(Sorter.bubble_sort([]), [])

    def test_bubble_sort_duplicates(self):
        self.assertEqual(Sorter.bubble_sort([3, 1, 3, 2, 1]), [1, 1, 2, 3, 3])

    # is_sorted
    def test_is_sorted_true(self):
        self.assertTrue(Sorter.is_sorted([1, 2, 2, 5]))

    def test_is_sorted_false(self):
        self.assertFalse(Sorter.is_sorted([3, 1, 2]))

    def test_is_sorted_empty(self):
        self.assertTrue(Sorter.is_sorted([]))

    # reverse_sort
    def test_reverse_sort_basic(self):
        self.assertEqual(Sorter.reverse_sort([5, 2, 9, 1]), [9, 5, 2, 1])

    def test_reverse_sort_already_sorted(self):
        self.assertEqual(Sorter.reverse_sort([1, 2, 3, 4]), [4, 3, 2, 1])

    def test_reverse_sort_duplicates(self):
        self.assertEqual(Sorter.reverse_sort([2, 3, 2, 1]), [3, 2, 2, 1])

if __name__ == "__main__":
    unittest.main()
