class Sorter:

    @staticmethod
    def bubble_sort(arr):
        result = list(arr)
        n = len(result)
        for i in range(n):
            for j in range(n - 1 - i):
                if result[j] > result[j + 1]:
                    result[j], result[j + 1] = result[j + 1], result[j]
        return result

    @staticmethod
    def is_sorted(arr):
        for i in range(len(arr) - 1):
            if arr[i] > arr[i + 1]:
                return False
        return True

    @staticmethod
    def reverse_sort(arr):
        result = list(arr)
        n = len(result)
        for i in range(n):
            for j in range(n - 1 - i):
                if result[j] < result[j + 1]:
                    result[j], result[j + 1] = result[j + 1], result[j]
        return result

if __name__ == "__main__":
    print(Sorter.bubble_sort([5, 2, 9, 1]))
    print(Sorter.is_sorted([1, 2, 3]))
    print(Sorter.reverse_sort([5, 2, 9, 1]))
