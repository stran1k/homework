import math

class Geometry:
    def __init__(self):
        pass

    def _check(self, *values):
        for value in values:
            if value <= 0:
                raise ValueError("Значение должно быть положительным")

    def area_circle(self, radius):
        self._check(radius)
        return math.pi * radius ** 2

    def perimeter_rectangle(self, length, width):
        self._check(length, width)
        return 2 * (length + width)

    def volume_cube(self, side):
        self._check(side)
        return side ** 3

    # Дополнительные 4 формулы

    def area_rectangle(self, length, width):
        self._check(length, width)
        return length * width

    def circumference(self, radius):
        self._check(radius)
        return 2 * math.pi * radius

    def area_triangle(self, base, height):
        self._check(base, height)
        return 0.5 * base * height

    def volume_sphere(self, radius):
        self._check(radius)
        return 4 / 3 * math.pi * radius ** 3

if __name__ == "__main__":
    geo = Geometry()

    print(geo.area_circle(2))
    print(geo.perimeter_rectangle(3, 4))
    print(geo.volume_cube(3))
    print(geo.area_rectangle(3, 4))
    print(geo.circumference(1))
    print(geo.area_triangle(6, 4))
    print(geo.volume_sphere(3))
