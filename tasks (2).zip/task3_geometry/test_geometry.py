import math
import unittest
from geometry import Geometry

class TestGeometry(unittest.TestCase):

    def setUp(self):
        self.geo = Geometry()

    # area_circle
    def test_area_circle_basic(self):
        self.assertAlmostEqual(self.geo.area_circle(2), math.pi * 4)

    def test_area_circle_zero(self):
        with self.assertRaises(ValueError):
            self.geo.area_circle(0)

    def test_area_circle_negative(self):
        with self.assertRaises(ValueError):
            self.geo.area_circle(-1)

    # perimeter_rectangle
    def test_perimeter_rectangle_basic(self):
        self.assertEqual(self.geo.perimeter_rectangle(3, 4), 14)

    def test_perimeter_rectangle_zero(self):
        with self.assertRaises(ValueError):
            self.geo.perimeter_rectangle(0, 4)

    def test_perimeter_rectangle_negative(self):
        with self.assertRaises(ValueError):
            self.geo.perimeter_rectangle(3, -4)

    # volume_cube
    def test_volume_cube_basic(self):
        self.assertEqual(self.geo.volume_cube(3), 27)

    def test_volume_cube_zero(self):
        with self.assertRaises(ValueError):
            self.geo.volume_cube(0)

    def test_volume_cube_negative(self):
        with self.assertRaises(ValueError):
            self.geo.volume_cube(-2)

    # area_rectangle
    def test_area_rectangle_basic(self):
        self.assertEqual(self.geo.area_rectangle(3, 4), 12)

    def test_area_rectangle_zero(self):
        with self.assertRaises(ValueError):
            self.geo.area_rectangle(3, 0)

    def test_area_rectangle_negative(self):
        with self.assertRaises(ValueError):
            self.geo.area_rectangle(-3, 4)

    # circumference
    def test_circumference_basic(self):
        self.assertAlmostEqual(self.geo.circumference(1), 2 * math.pi)

    def test_circumference_zero(self):
        with self.assertRaises(ValueError):
            self.geo.circumference(0)

    def test_circumference_negative(self):
        with self.assertRaises(ValueError):
            self.geo.circumference(-5)

    # area_triangle
    def test_area_triangle_basic(self):
        self.assertEqual(self.geo.area_triangle(6, 4), 12)

    def test_area_triangle_zero(self):
        with self.assertRaises(ValueError):
            self.geo.area_triangle(0, 4)

    def test_area_triangle_negative(self):
        with self.assertRaises(ValueError):
            self.geo.area_triangle(6, -4)

    # volume_sphere
    def test_volume_sphere_basic(self):
        self.assertAlmostEqual(self.geo.volume_sphere(3), 36 * math.pi)

    def test_volume_sphere_zero(self):
        with self.assertRaises(ValueError):
            self.geo.volume_sphere(0)

    def test_volume_sphere_negative(self):
        with self.assertRaises(ValueError):
            self.geo.volume_sphere(-3)

if __name__ == "__main__":
    unittest.main()
