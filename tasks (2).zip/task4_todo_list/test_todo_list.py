import unittest
from todo_list import TodoList

class TestTodoList(unittest.TestCase):

    def setUp(self):
        self.todo = TodoList()

    # add_task
    def test_add_task_basic(self):
        self.todo.add_task("Купить хлеб")
        self.todo.add_task("Сделать уроки")
        self.assertEqual(self.todo.get_tasks(), ["Купить хлеб", "Сделать уроки"])

    def test_add_task_empty_string(self):
        with self.assertRaises(ValueError):
            self.todo.add_task("")
        with self.assertRaises(ValueError):
            self.todo.add_task("   ")

    def test_add_task_not_string(self):
        with self.assertRaises(ValueError):
            self.todo.add_task(123)
        self.assertEqual(self.todo.get_tasks(), [])

    # remove_task
    def test_remove_task_basic(self):
        self.todo.add_task("Купить хлеб")
        self.todo.add_task("Сделать уроки")
        self.todo.remove_task("Купить хлеб")
        self.assertEqual(self.todo.get_tasks(), ["Сделать уроки"])

    def test_remove_task_not_exists(self):
        self.todo.add_task("Купить хлеб")
        with self.assertRaises(ValueError):
            self.todo.remove_task("Погулять")
        self.assertEqual(self.todo.get_tasks(), ["Купить хлеб"])

    def test_remove_task_from_empty_list(self):
        with self.assertRaises(ValueError):
            self.todo.remove_task("Купить хлеб")

    # get_tasks
    def test_get_tasks_empty(self):
        self.assertEqual(self.todo.get_tasks(), [])

    def test_get_tasks_returns_copy(self):
        self.todo.add_task("Купить хлеб")
        tasks = self.todo.get_tasks()
        tasks.append("Чужая задача")
        self.assertEqual(self.todo.get_tasks(), ["Купить хлеб"])

    def test_get_tasks_after_remove_all(self):
        self.todo.add_task("Купить хлеб")
        self.todo.remove_task("Купить хлеб")
        self.assertEqual(self.todo.get_tasks(), [])

if __name__ == "__main__":
    unittest.main()
