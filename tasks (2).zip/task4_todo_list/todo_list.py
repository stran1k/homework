class TodoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        if not isinstance(task, str) or task.strip() == "":
            raise ValueError("Задача должна быть непустой строкой")
        self.tasks.append(task)

    def remove_task(self, task):
        if task not in self.tasks:
            raise ValueError("Такой задачи нет в списке")
        self.tasks.remove(task)

    def get_tasks(self):
        return self.tasks.copy()

if __name__ == "__main__":
    todo = TodoList()

    todo.add_task("Купить хлеб")
    todo.add_task("Сделать уроки")
    todo.remove_task("Купить хлеб")
    print(todo.get_tasks())
