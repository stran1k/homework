import random

class RockPaperScissors:

    CHOICES = ["rock", "paper", "scissors"]
    WINS = {"rock": "scissors", "paper": "rock", "scissors": "paper"}

    def play(self, player_choice):
        if not isinstance(player_choice, str):
            raise ValueError("Выбор должен быть строкой")
        if player_choice not in self.CHOICES:
            raise ValueError("Допустимо: rock, paper или scissors")

        computer_choice = random.choice(self.CHOICES)

        if player_choice == computer_choice:
            return "tie"
        if self.WINS[player_choice] == computer_choice:
            return "win"
        return "lose"

if __name__ == "__main__":
    game = RockPaperScissors()
    print(game.play("rock"))
