import unittest
from unittest.mock import patch
from rock_paper_scissors import RockPaperScissors

# patch подменяет случайный выбор компьютера на заданный

class TestRockPaperScissors(unittest.TestCase):

    def setUp(self):
        self.game = RockPaperScissors()

    # победы
    @patch("random.choice", return_value="scissors")
    def test_rock_beats_scissors(self, mock_choice):
        self.assertEqual(self.game.play("rock"), "win")

    @patch("random.choice", return_value="rock")
    def test_paper_beats_rock(self, mock_choice):
        self.assertEqual(self.game.play("paper"), "win")

    @patch("random.choice", return_value="paper")
    def test_scissors_beats_paper(self, mock_choice):
        self.assertEqual(self.game.play("scissors"), "win")

    # поражения
    @patch("random.choice", return_value="paper")
    def test_rock_loses_to_paper(self, mock_choice):
        self.assertEqual(self.game.play("rock"), "lose")

    @patch("random.choice", return_value="scissors")
    def test_paper_loses_to_scissors(self, mock_choice):
        self.assertEqual(self.game.play("paper"), "lose")

    @patch("random.choice", return_value="rock")
    def test_scissors_loses_to_rock(self, mock_choice):
        self.assertEqual(self.game.play("scissors"), "lose")

    # ничьи
    @patch("random.choice", return_value="rock")
    def test_tie_rock(self, mock_choice):
        self.assertEqual(self.game.play("rock"), "tie")

    @patch("random.choice", return_value="paper")
    def test_tie_paper(self, mock_choice):
        self.assertEqual(self.game.play("paper"), "tie")

    @patch("random.choice", return_value="scissors")
    def test_tie_scissors(self, mock_choice):
        self.assertEqual(self.game.play("scissors"), "tie")

    # ошибки
    def test_invalid_choice(self):
        with self.assertRaises(ValueError):
            self.game.play("lizard")

    def test_not_string(self):
        with self.assertRaises(ValueError):
            self.game.play(123)

    def test_empty_string(self):
        with self.assertRaises(ValueError):
            self.game.play("")

if __name__ == "__main__":
    unittest.main()
