import re

class EmailValidator:

    PATTERN = r"^[\w.+-]+@[\w-]+(\.[\w-]+)*\.[A-Za-z]{2,}$"

    @staticmethod
    def is_valid(email):
        if not isinstance(email, str):
            raise ValueError("Email должен быть строкой")
        return re.match(EmailValidator.PATTERN, email) is not None

    @staticmethod
    def extract_domain(email):
        if not EmailValidator.is_valid(email):
            raise ValueError("Некорректный email")
        return email.split("@")[1]

    @staticmethod
    def is_gmail(email):
        if not EmailValidator.is_valid(email):
            return False
        return EmailValidator.extract_domain(email).lower() == "gmail.com"

if __name__ == "__main__":
    print(EmailValidator.is_valid("user@mail.ru"))
    print(EmailValidator.extract_domain("user@mail.ru"))
    print(EmailValidator.is_gmail("User@Gmail.com"))
