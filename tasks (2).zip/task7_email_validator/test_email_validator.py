import unittest
from email_validator import EmailValidator

class TestEmailValidator(unittest.TestCase):

    # is_valid
    def test_is_valid_correct(self):
        self.assertTrue(EmailValidator.is_valid("user.name@mail.ru"))

    def test_is_valid_incorrect(self):
        self.assertFalse(EmailValidator.is_valid("user.mail.ru"))

    def test_is_valid_not_string(self):
        with self.assertRaises(ValueError):
            EmailValidator.is_valid(12345)

    # extract_domain
    def test_extract_domain_basic(self):
        self.assertEqual(EmailValidator.extract_domain("user@yandex.ru"), "yandex.ru")

    def test_extract_domain_subdomain(self):
        self.assertEqual(EmailValidator.extract_domain("admin@mail.company.com"), "mail.company.com")

    def test_extract_domain_invalid(self):
        with self.assertRaises(ValueError):
            EmailValidator.extract_domain("no-at-sign.com")

    # is_gmail
    def test_is_gmail_true(self):
        self.assertTrue(EmailValidator.is_gmail("user@gmail.com"))

    def test_is_gmail_case_insensitive(self):
        self.assertTrue(EmailValidator.is_gmail("User@GMAIL.COM"))

    def test_is_gmail_false(self):
        self.assertFalse(EmailValidator.is_gmail("user@mail.ru"))

if __name__ == "__main__":
    unittest.main()
