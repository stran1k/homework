import unittest
from bank_account import BankAccount

class TestBankAccount(unittest.TestCase):

    def setUp(self):
        self.account = BankAccount(100)

    def test_deposit_basic(self):
        self.account.deposit(50)
        self.assertEqual(self.account.get_balance(), 150.0)

    def test_deposit_zero(self):
        with self.assertRaises(ValueError):
            self.account.deposit(0)

    def test_deposit_negative(self):
        with self.assertRaises(ValueError):
            self.account.deposit(-10)

    def test_withdraw_basic(self):
        self.account.withdraw(30)
        self.assertEqual(self.account.get_balance(), 70.0)

    def test_withdraw_not_enough_money(self):
        with self.assertRaises(ValueError):
            self.account.withdraw(200)

    def test_withdraw_zero_and_negative(self):
        with self.assertRaises(ValueError):
            self.account.withdraw(0)
        with self.assertRaises(ValueError):
            self.account.withdraw(-5)

    def test_get_balance_basic(self):
        self.assertEqual(self.account.get_balance(), 100.0)

    def test_get_balance_empty(self):
        self.assertEqual(BankAccount().get_balance(), 0.0)

    def test_get_balance_is_float(self):
        self.assertIsInstance(self.account.get_balance(), float)

if __name__ == "__main__":
    unittest.main()
